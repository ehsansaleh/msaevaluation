
The "PlottingScript.py" generates the figures used in the article.

The output folder includes multiple folders, within which the generated figures are
put in 3 different formats. Some figures include comments that are generated automatically.

